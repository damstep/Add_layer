.pragma library
.import org.qgis.core 1.0 as QGIS
.import QtQml 2.0 as QML
.import QtQuick 2.0 as Quick

var targetDir = ""

function selectDirectory() {
    var dir = QField.askDirectory("Choose Target Directory")
    if (dir) {
        targetDir = dir
        QField.toast("Selected: " + dir)
    } else {
        QField.toast("No directory selected")
    }
}

function loadLayer() {
    var filePath = QField.askFile("Select layer to import", "*.*")
    if (!filePath) {
        QField.toast("No file selected")
        return
    }

    var layer = new QGIS.QgsVectorLayer(filePath, filePath.split("/").pop(), "ogr")
    if (!layer.isValid()) {
        QField.toast("Failed to load layer")
        return
    }

    var gpkgPath = targetDir + "/data.gpkg"
    var outName = layer.name().replace(/\W+/g, "_")

    var opts = new QGIS.QgsVectorFileWriter.SaveVectorOptions()
    opts.driverName = "GPKG"
    opts.layerName = outName
    opts.actionOnExistingFile = QGIS.QgsVectorFileWriter.CreateOrOverwriteLayer

    var result = QGIS.QgsVectorFileWriter.writeAsVectorFormatV3(
        layer,
        gpkgPath,
        QGIS.QgsCoordinateTransformContext(),
        opts
    )

    if (result[0] !== QGIS.QgsVectorFileWriter.NoError) {
        QField.toast("Conversion failed: " + result[0])
        return
    }

    var newLayer = new QGIS.QgsVectorLayer(gpkgPath + "|layername=" + outName, outName, "ogr")
    QGIS.QgsProject.instance().addMapLayer(newLayer)
    QField.toast("Imported & converted to GeoPackage")

    saveProject()
}

function saveProject() {
    var projPath = targetDir + "/project.qgz"
    var ok = QGIS.QgsProject.instance().write(projPath)
    if (ok)
        QField.toast("Project auto-saved")
    else
        QField.toast("Failed to save project")
}

function packageProject() {
    var projDir = targetDir + "/QFieldPackage"
    QField.makeDir(projDir)

    var projPath = targetDir + "/project.qgz"
    QField.copyFile(projPath, projDir + "/project.qgz")

    var gpkg = targetDir + "/data.gpkg"
    if (QField.fileExists(gpkg))
        QField.copyFile(gpkg, projDir + "/data.gpkg")

    QField.toast("Project packaged into: " + projDir)
}